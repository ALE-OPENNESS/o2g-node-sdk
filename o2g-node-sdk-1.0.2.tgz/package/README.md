# o2g-sdk-node

A Node.js SDK for the O2G platform, providing tools to interact with O2G telephony and call control features.

## Installation

Install via npm:

```bash
npm install o2g-sdk-node
